
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { UserProfile, Message } from "../types";

// Always initialize GoogleGenAI using the process.env.API_KEY environment variable.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeHealthScore = async (profile: UserProfile) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this user health profile: ${JSON.stringify(profile)}. 
    1. Provide a wellness score (0-100).
    2. Identify key concerns.
    3. Predict the risk of potential future diseases or viruses based on their current vitals and clinical history.
    4. Provide risk probabilities in percentages only.
    5. Classify the overall profile into "Low Risk", "Moderate Risk", or "High Risk".`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER },
          keyConcerns: { type: Type.ARRAY, items: { type: Type.STRING } },
          priorityActions: { type: Type.ARRAY, items: { type: Type.STRING } },
          riskClassification: { 
            type: Type.STRING, 
            description: "Classification: Low Risk, Moderate Risk, or High Risk" 
          },
          diseaseRisks: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                disease: { type: Type.STRING },
                probability: { type: Type.NUMBER, description: "Percentage risk (0-100)" }
              },
              required: ["disease", "probability"]
            }
          }
        },
        required: ["score", "keyConcerns", "priorityActions", "riskClassification", "diseaseRisks"],
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

export const getHabitFeedback = async (profile: UserProfile) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Based on this user health profile: ${JSON.stringify(profile)}, provide 3 actionable habit improvement tips.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            tip: { type: Type.STRING },
          },
          required: ["title", "tip"],
        },
      }
    }
  });
  return JSON.parse(response.text || '[]');
};

export const chatWithAssistant = async (history: Message[], userInput: string, clinicalSummary?: string) => {
  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: `You are AuraChat, an advanced medical-companion AI. 
      Context of current user's clinical summary: ${clinicalSummary || 'Not yet generated'}.
      
      RULES FOR RESPONDING:
      1. Be empathetic, snappy, and use relevant emojis (e.g., 🩺, ✨, ✦).
      2. If asked about chronic conditions like **Diabetes**, provide an EXTREMELY organized response:
         - Use **Bold Headers** for main sections.
         - Use bullet points (using ✦ or •) for clarity.
         - Avoid large walls of text.
         - Do not use markdown "stats" blocks unless specifically asked for raw data.
      3. Focus on proactive health and preventative measures.
      4. Always maintain a professional yet warm and encouraging tone.`,
    }
  });

  const response = await chat.sendMessage({ message: userInput });
  return response.text;
};

export const getStressFeedback = async (stressLevel: number) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Give a short, empathetic wellness tip for someone with a stress level of ${stressLevel}/100.`,
  });
  return response.text;
};

export const generateHealingStory = async (stressLevel: number) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Write a 100-word healing visualization story for someone with stress level ${stressLevel}. Make it sensory, peaceful, and starting with "Close your eyes. Imagine...".`,
  });
  return response.text;
};

export const reciteText = async (text: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Speak this in a natural, brisk, and efficient tone. Do not speak slowly: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });
  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
};

export const generateDoctorSummary = async (profile: UserProfile) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Create a professional, highly detailed clinical summary in HTML format for this patient profile: ${JSON.stringify(profile)}. 
    Use semantic HTML tags (h1, h2, p, ul, li) and professional inline CSS for styling. 
    Include patient details, health trends, risk factors, and recommended next steps. 
    Make it look like a formal medical report with a clean white background and indigo accents.`,
  });
  return response.text;
};
