
import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, DashboardTab, Message, ClinicalCondition, CheckupLog, CalendarEvent } from './types';
import { analyzeHealthScore, getHabitFeedback, generateDoctorSummary, chatWithAssistant } from './services/geminiService';
import { HabitTracker } from './components/HabitTracker';
import { MentalHealth } from './components/MentalHealth';
import { DoctorPortal } from './components/DoctorPortal';
import { Trends } from './components/Trends';
import { Calendar } from './components/Calendar';

const App: React.FC = () => {
  // Persistence Initialization
  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('aura_health_profile_v2');
    if (saved) return JSON.parse(saved);
    return {
      firstName: '', lastName: '', email: '', age: 0, gender: '',
      height: 0, weight: 0, bloodPressure: { systolic: 0, diastolic: 0 },
      bloodSugar: 0, diet: '', activity: '', hydration: 0,
      steps: 0, heartRate: 0, spo2: 0, breathing: 0, sleep: 0,
      clinicalHistory: [], manualDiseases: '',
      uploadedFile: null, familyHistory: [],
      checkups: [],
      events: []
    };
  });

  const [step, setStep] = useState<'signup' | 'privacy' | 'vitals' | 'habits' | 'clinical' | 'analyzing' | 'dashboard'>(
    profile.firstName ? 'dashboard' : 'signup'
  );
  const [activeTab, setActiveTab] = useState<DashboardTab>('insights');
  const [analysis, setAnalysis] = useState<any>(null);
  const [habitFeedback, setHabitFeedback] = useState<any[]>([]);
  const [docSummary, setDocSummary] = useState("");
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [chatHistory, setChatHistory] = useState<Message[]>([]);
  const [currentChatInput, setCurrentChatInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem('aura_health_profile_v2', JSON.stringify(profile));
  }, [profile]);

  const DISEASES = ["Cardiac Arrest", "High BP", "Diabetes", "Hypertension", "Asthma", "Cholesterol"];

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  // Initial trigger for AuraChat to summarize the report
  useEffect(() => {
    if (activeTab === 'vitality' && chatHistory.length === 0 && docSummary) {
      handleAutoSummarize();
    }
  }, [activeTab]);

  const handleAutoSummarize = async () => {
    setIsTyping(true);
    try {
      const summaryPrompt = "I've just generated your clinical report. Could you provide me with a snappy, empathetic 3-sentence summary of my status and then ask me if I have any specific questions about it?";
      const aiResponse = await chatWithAssistant([], summaryPrompt, docSummary);
      setChatHistory([{ role: 'assistant', content: aiResponse || "Hello! I've reviewed your clinical data. What would you like to know?" }]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsTyping(false);
    }
  };

  const handleSendMessage = async () => {
    if (!currentChatInput.trim()) return;
    const userMsg: Message = { role: 'user', content: currentChatInput };
    setChatHistory(prev => [...prev, userMsg]);
    setCurrentChatInput("");
    setIsTyping(true);
    
    try {
      const aiResponse = await chatWithAssistant(chatHistory, currentChatInput, docSummary);
      setChatHistory(prev => [...prev, { role: 'assistant', content: aiResponse || "I'm with you on your health journey!" }]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsTyping(false);
    }
  };

  const handleAnalyze = async () => {
    setStep('analyzing');
    try {
      const [scoreRes, habitRes] = await Promise.all([
        analyzeHealthScore(profile),
        getHabitFeedback(profile)
      ]);
      setAnalysis(scoreRes);
      setHabitFeedback(habitRes);
      const summary = await generateDoctorSummary(profile);
      setDocSummary(summary);
      setStep('dashboard');
    } catch (err) {
      console.error(err);
      setStep('clinical');
    }
  };

  const toggleDisease = (d: string) => {
    setProfile(p => {
      const exists = p.clinicalHistory.find(item => item.condition === d);
      if (exists) {
        return { ...p, clinicalHistory: p.clinicalHistory.filter(i => i.condition !== d) };
      } else {
        return { ...p, clinicalHistory: [...p.clinicalHistory, { condition: d, ageAtDiagnosis: p.age || 0 }] };
      }
    });
  };

  const updateDiagnosisAge = (condition: string, age: number) => {
    setProfile(p => ({
      ...p,
      clinicalHistory: p.clinicalHistory.map(item => 
        item.condition === condition ? { ...item, ageAtDiagnosis: age } : item
      )
    }));
  };

  const getAvatarUrl = () => {
    if (profile.gender === 'male') return 'https://avatar.iran.liara.run/public/boy';
    if (profile.gender === 'female') return 'https://avatar.iran.liara.run/public/girl';
    return 'https://avatar.iran.liara.run/public';
  };

  const handleSignOut = () => {
    localStorage.clear();
    setProfile({
      firstName: '', lastName: '', email: '', age: 0, gender: '',
      height: 0, weight: 0, bloodPressure: { systolic: 0, diastolic: 0 },
      bloodSugar: 0, diet: '', activity: '', hydration: 0,
      steps: 0, heartRate: 0, spo2: 0, breathing: 0, sleep: 0,
      clinicalHistory: [], manualDiseases: '',
      uploadedFile: null, familyHistory: [],
      checkups: [],
      events: []
    });
    setStep('signup');
    window.location.reload(); // Hard reload to ensure all states are cleared
  };

  const isSignupValid = profile.firstName.trim() !== '' && profile.lastName.trim() !== '' && profile.email.includes('@');
  const isVitalsValid = profile.age > 0 && profile.gender !== '' && profile.height > 0 && profile.weight > 0;
  const isHabitsValid = profile.activity !== '';

  if (step === 'signup') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-100 via-white to-blue-50">
        <div className="glass w-full max-w-md p-10 rounded-[3rem] shadow-2xl animate-scaleIn border-white/50">
          <div className="flex flex-col items-center text-center mb-10">
            <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-black shadow-lg shadow-indigo-100 mb-6 text-xl">A</div>
            <h1 className="text-4xl font-black text-indigo-900 mb-2 tracking-tighter">AuraHealth</h1>
            <p className="text-slate-500 font-bold uppercase text-[10px] tracking-[0.2em]">Next-Gen Health Ecosystem</p>
          </div>
          <div className="space-y-4">
            <div className="flex gap-4">
              <input type="text" placeholder="First Name" className="w-1/2 p-4 bg-white/50 border border-slate-100 rounded-2xl outline-none font-bold" value={profile.firstName} onChange={e => setProfile({...profile, firstName: e.target.value})} />
              <input type="text" placeholder="Last Name" className="w-1/2 p-4 bg-white/50 border border-slate-100 rounded-2xl outline-none font-bold" value={profile.lastName} onChange={e => setProfile({...profile, lastName: e.target.value})} />
            </div>
            <input type="email" placeholder="Email Address" className="w-full p-4 bg-white/50 border border-slate-100 rounded-2xl outline-none font-bold" value={profile.email} onChange={e => setProfile({...profile, email: e.target.value})} />
            <button 
              disabled={!isSignupValid}
              onClick={() => setStep('privacy')} 
              className={`w-full py-5 rounded-[1.5rem] font-black tracking-widest transition-all shadow-xl uppercase text-xs ${isSignupValid ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-100' : 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'}`}
            >
              Join System →
            </button>
            {!isSignupValid && <p className="text-[9px] text-rose-400 font-bold text-center uppercase tracking-widest mt-2">Required: Full name & valid email</p>}
          </div>
        </div>
      </div>
    );
  }

  if (step === 'privacy') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-100 via-white to-blue-50">
        <div className="glass w-full max-w-2xl p-10 rounded-[3rem] shadow-2xl animate-scaleIn border-white/50">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-black text-indigo-900 mb-2 tracking-tighter uppercase">Privacy Policy</h1>
            <p className="text-slate-500 font-bold uppercase text-[10px] tracking-[0.2em]">Legal Disclosure & Consent</p>
          </div>
          <div className="space-y-6">
            <div className="p-8 bg-white/60 rounded-3xl border border-slate-100 shadow-inner max-h-[350px] overflow-y-auto scrollbar-thin scrollbar-thumb-slate-200">
              <ul className="space-y-4 text-sm font-medium text-slate-700 leading-relaxed">
                {[
                  "We respect your privacy and are committed to protecting your personal information.",
                  "The app collects only minimal data required to provide health-related features.",
                  "Any health data shared by users is stored securely and treated as confidential.",
                  "We do not sell, share, or disclose user data to third parties.",
                  "Collected data is used only to improve app performance and user experience.",
                  "Security measures are implemented to prevent unauthorized access to information.",
                  "Users can request deletion of their data at any time.",
                  "This app is for informational purposes only and does not replace medical advice.",
                  "By using this app, you agree to the terms of this privacy policy."
                ].map((point, i) => (
                  <li key={i} className="flex gap-3 items-start">
                    <span className="text-indigo-600 font-black mt-1">0{i+1}</span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="flex flex-col items-center gap-6 pt-4 border-t border-white/50">
              <div className="flex items-center gap-3">
                <input type="checkbox" id="consent" className="w-5 h-5 rounded-lg border-indigo-200 text-indigo-600 focus:ring-indigo-400 cursor-pointer" checked={agreedToTerms} onChange={(e) => setAgreedToTerms(e.target.checked)} />
                <label htmlFor="consent" className="text-xs font-black text-slate-600 uppercase tracking-widest cursor-pointer select-none">
                  I UNDERSTAND & accept terms and conditions
                </label>
              </div>
              <div className="flex gap-4 w-full">
                <button onClick={() => setStep('signup')} className="flex-1 py-4 bg-slate-100 text-slate-500 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-200 transition-all">Back</button>
                <button disabled={!agreedToTerms} onClick={() => setStep('vitals')} className={`flex-[2] py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all shadow-lg ${agreedToTerms ? 'bg-slate-900 text-white hover:bg-black shadow-slate-200' : 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'}`}>Next →</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (step === 'vitals' || step === 'habits' || step === 'clinical') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50">
        <div className="bg-white w-full max-w-xl p-10 rounded-[3rem] shadow-xl border border-slate-100">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-black text-slate-900">{step === 'vitals' ? 'Core Vitals' : step === 'habits' ? 'Living' : 'Clinical Hub'}</h2>
            <div className="flex gap-1.5">
              <div className={`w-2.5 h-2.5 rounded-full ${step === 'vitals' ? 'bg-indigo-600' : 'bg-slate-200'}`}></div>
              <div className={`w-2.5 h-2.5 rounded-full ${step === 'habits' ? 'bg-indigo-600' : 'bg-slate-200'}`}></div>
              <div className={`w-2.5 h-2.5 rounded-full ${step === 'clinical' ? 'bg-indigo-600' : 'bg-slate-200'}`}></div>
            </div>
          </div>

          <div className="space-y-6">
            {step === 'vitals' && (
              <div className="space-y-8 animate-fadeIn">
                <div>
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Demographics</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-400 ml-2 uppercase">Your Age</label>
                      <input type="number" className="w-full p-4 bg-slate-50 rounded-2xl font-bold border-none outline-none focus:ring-2 focus:ring-indigo-100" value={profile.age || ''} onChange={e => setProfile({...profile, age: Number(e.target.value)})} />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-400 ml-2 uppercase">Gender</label>
                      <select className="w-full p-4 bg-slate-50 rounded-2xl font-bold border-none outline-none focus:ring-2 focus:ring-indigo-100" value={profile.gender} onChange={e => setProfile({...profile, gender: e.target.value})}>
                        <option value="">Select Gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Body Metrics</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-400 ml-2 uppercase">Height (CM)</label>
                      <input type="number" className="w-full p-4 bg-slate-50 rounded-2xl font-bold border-none outline-none focus:ring-2 focus:ring-indigo-100" value={profile.height || ''} onChange={e => setProfile({...profile, height: Number(e.target.value)})} />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-400 ml-2 uppercase">Weight (KG)</label>
                      <input type="number" className="w-full p-4 bg-slate-50 rounded-2xl font-bold border-none outline-none focus:ring-2 focus:ring-indigo-100" value={profile.weight || ''} onChange={e => setProfile({...profile, weight: Number(e.target.value)})} />
                    </div>
                  </div>
                </div>
              </div>
            )}
            {step === 'habits' && (
              <div className="space-y-8 animate-fadeIn">
                <div>
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Daily Activity Intensity</h4>
                  <div className="flex gap-2">
                    {['Sedentary', 'Moderate', 'Active'].map(l => (
                      <button key={l} onClick={() => setProfile({...profile, activity: l})} className={`flex-1 py-4 rounded-xl font-bold text-xs transition-all ${profile.activity === l ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-50 text-slate-400 hover:bg-slate-100'}`}>{l}</button>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Target Hydration: {profile.hydration}L</h4>
                  <input type="range" min="0" max="5" step="0.5" className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600" value={profile.hydration} onChange={e => setProfile({...profile, hydration: Number(e.target.value)})} />
                </div>
              </div>
            )}
            {step === 'clinical' && (
              <div className="space-y-6 animate-fadeIn">
                <div>
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">DIAGNOSTIC REPORTS</h4>
                  <div className="p-8 border-2 border-dashed border-indigo-200 bg-indigo-50/20 rounded-3xl text-center group hover:border-indigo-400 transition-all hover:bg-indigo-50/40 relative">
                    <input 
                      type="file" 
                      id="report-upload" 
                      className="hidden" 
                      onChange={e => setProfile({...profile, uploadedFile: e.target.files?.[0]?.name || null})} 
                    />
                    <label htmlFor="report-upload" className="cursor-pointer block w-full h-full">
                      <div className="flex flex-col items-center">
                        <span className="text-4xl mb-3 group-hover:scale-110 transition-transform">📁</span>
                        {profile.uploadedFile ? (
                          <div className="space-y-1">
                            <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">ATTACHED REPORT</p>
                            <p className="text-sm font-bold text-slate-700 truncate max-w-[200px]">{profile.uploadedFile}</p>
                            <button 
                              type="button" 
                              onClick={(e) => { e.preventDefault(); setProfile({...profile, uploadedFile: null}); }}
                              className="text-[9px] font-black text-rose-500 uppercase tracking-widest hover:underline"
                            >
                              Remove File
                            </button>
                          </div>
                        ) : (
                          <p className="text-xs font-black text-indigo-500 uppercase tracking-widest">
                            CLICK TO ATTACH DIAGNOSTIC REPORT <br/>
                            <span className="text-[9px] opacity-60 font-bold lowercase italic">(opens file explorer)</span>
                          </p>
                        )}
                      </div>
                    </label>
                  </div>
                </div>

                <div>
                  <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Existing Medical Conditions</h4>
                  <div className="grid grid-cols-2 gap-2 mb-6">
                    {DISEASES.map(d => {
                      const isSelected = profile.clinicalHistory.some(item => item.condition === d);
                      return (
                        <button key={d} onClick={() => toggleDisease(d)} className={`p-3 rounded-xl border text-[10px] font-black uppercase transition-all ${isSelected ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' : 'bg-white border-slate-100 text-slate-600 hover:border-indigo-100'}`}>{d}</button>
                      );
                    })}
                  </div>
                  {profile.clinicalHistory.length > 0 && (
                    <div className="space-y-3 mb-6 animate-fadeIn">
                      <h4 className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.2em]">Age at Diagnosis</h4>
                      {profile.clinicalHistory.map((item, idx) => (
                        <div key={idx} className="flex items-center gap-4 bg-slate-50 p-3 rounded-2xl border border-slate-100">
                          <span className="text-[10px] font-black text-slate-600 flex-1 truncate">{item.condition}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-[9px] font-bold text-slate-400 uppercase">Diagnosed Age:</span>
                            <input type="number" className="w-16 p-1.5 bg-white border border-slate-200 rounded-lg text-xs font-bold text-center outline-none focus:ring-1 focus:ring-indigo-400" value={item.ageAtDiagnosis || ''} onChange={(e) => updateDiagnosisAge(item.condition, Number(e.target.value))} />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  <input type="text" placeholder="Other medical history or symptoms..." className="w-full p-4 bg-slate-50 rounded-2xl text-sm font-medium border-none outline-none focus:ring-2 focus:ring-indigo-100" value={profile.manualDiseases} onChange={e => setProfile({...profile, manualDiseases: e.target.value})} />
                </div>
              </div>
            )}
            <div className="flex gap-3 pt-6 border-t border-slate-50">
              <button onClick={() => setStep(step === 'vitals' ? 'privacy' : step === 'habits' ? 'vitals' : 'clinical')} className="flex-1 py-4 bg-slate-100 text-slate-500 rounded-2xl font-black text-[10px] uppercase hover:bg-slate-200 transition-colors">Back</button>
              <button 
                disabled={step === 'vitals' ? !isVitalsValid : step === 'habits' ? !isHabitsValid : false}
                onClick={step === 'clinical' ? handleAnalyze : () => setStep(step === 'vitals' ? 'habits' : 'clinical')} 
                className={`flex-[2] py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all shadow-lg ${((step === 'vitals' && !isVitalsValid) || (step === 'habits' && !isHabitsValid)) ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-slate-900 text-white hover:bg-black'}`}
              >
                {step === 'clinical' ? 'Run Bio-Analysis' : 'Next Step'}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (step === 'analyzing') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-indigo-950 text-white">
        <div className="relative w-32 h-32 mb-12">
          <div className="absolute inset-0 border-4 border-white/10 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-t-indigo-500 rounded-full animate-spin"></div>
        </div>
        <h2 className="text-2xl font-black tracking-[0.3em] uppercase animate-pulse">Computing Bio-Signature</h2>
        <p className="mt-4 text-[10px] font-black text-indigo-400 uppercase tracking-widest opacity-60 text-center">Synthesizing clinical history and vital metrics for {profile.firstName}...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col relative">
      {/* Profile Detail Modal Overlay */}
      {showProfileMenu && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-indigo-950/40 backdrop-blur-sm animate-fadeIn">
          <div className="glass w-full max-w-sm p-10 rounded-[3rem] shadow-2xl relative border-white/40">
            <button onClick={() => setShowProfileMenu(false)} className="absolute top-6 right-6 w-8 h-8 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center font-black text-xs hover:bg-rose-50 hover:text-rose-500 transition-all">✕</button>
            <div className="text-center mb-8">
              <div className="w-24 h-24 mx-auto mb-6 rounded-full border-4 border-white shadow-xl overflow-hidden ring-8 ring-indigo-50">
                <img src={getAvatarUrl()} alt="Profile" className="w-full h-full object-cover" />
              </div>
              <h3 className="text-2xl font-black text-indigo-900 tracking-tighter">{profile.firstName} {profile.lastName}</h3>
              <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mt-1">{profile.email}</p>
            </div>
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="p-4 bg-slate-50/50 rounded-2xl">
                <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Age</p>
                <p className="text-sm font-black text-slate-800">{profile.age} Years</p>
              </div>
              <div className="p-4 bg-slate-50/50 rounded-2xl">
                <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Gender</p>
                <p className="text-sm font-black text-slate-800 capitalize">{profile.gender}</p>
              </div>
              <div className="p-4 bg-slate-50/50 rounded-2xl">
                <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Height</p>
                <p className="text-sm font-black text-slate-800">{profile.height} cm</p>
              </div>
              <div className="p-4 bg-slate-50/50 rounded-2xl">
                <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Weight</p>
                <p className="text-sm font-black text-slate-800">{profile.weight} kg</p>
              </div>
            </div>
            <button onClick={handleSignOut} className="w-full py-4 bg-rose-50 text-rose-600 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-rose-100 transition-all">Sign Out System</button>
          </div>
        </div>
      )}

      <header className="sticky top-0 z-50 glass px-8 py-4 flex items-center justify-between border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-black shadow-lg shadow-indigo-100">A</div>
          <h1 className="text-lg font-black text-indigo-900 tracking-tighter">AuraHealth</h1>
        </div>
        <nav className="hidden lg:flex items-center gap-1.5 p-1 bg-slate-100 rounded-2xl overflow-x-auto max-w-full">
          {['insights', 'mental-health', 'vitality', 'medical', 'trends', 'calendar'].map(t => (
            <button key={t} onClick={() => setActiveTab(t as DashboardTab)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeTab === t ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}>{t.replace('-', ' ')}</button>
          ))}
        </nav>
        <div className="flex items-center gap-4 relative">
          <button onClick={() => setShowProfileMenu(true)} className="w-10 h-10 rounded-full border-2 border-indigo-100 overflow-hidden ring-4 ring-white shadow-sm hover:ring-indigo-50 transition-all">
            <img src={getAvatarUrl()} alt="User" className="w-full h-full object-cover" />
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-8">
        <div className="mb-10 animate-slideDown flex justify-between items-end">
          <div>
            <h2 className="text-4xl font-black text-slate-900 mb-2 leading-none">Hello, {profile.firstName || 'User'}!</h2>
            <p className="text-slate-400 font-bold uppercase text-[10px] tracking-widest">Global Status: Synchronized • Bio-Signature Verified</p>
          </div>
          {analysis && (
            <div className="flex items-center gap-3 bg-white px-6 py-3 rounded-2xl shadow-sm border border-slate-100 animate-fadeIn">
              <span className={`w-3 h-3 rounded-full animate-pulse ${analysis.riskClassification === 'High Risk' ? 'bg-rose-500' : analysis.riskClassification === 'Moderate Risk' ? 'bg-amber-500' : 'bg-green-500'}`}></span>
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-800">Triage Status: {analysis.riskClassification}</p>
            </div>
          )}
        </div>

        {activeTab === 'insights' && (
          <div className="space-y-12">
            {analysis && (
              <div className="animate-fadeIn">
                <div className="dark-glass rounded-[3rem] p-10 shadow-2xl relative overflow-hidden text-white border-white/5">
                  <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-[100px] -mr-48 -mt-48 pointer-events-none"></div>
                  <div className="flex flex-col lg:flex-row gap-12 items-start relative z-10">
                    <div className="lg:w-1/3">
                      <h3 className="text-3xl font-black mb-4 tracking-tighter">Bio-Risk Analysis</h3>
                      <div className={`inline-block px-8 py-4 rounded-3xl border ${analysis.riskClassification === 'High Risk' ? 'bg-rose-500/20 border-rose-500/30 text-rose-400' : analysis.riskClassification === 'Moderate Risk' ? 'bg-amber-500/20 border-amber-500/30 text-amber-400' : 'bg-green-500/20 border-green-500/30 text-green-400'}`}>
                        <p className="text-[10px] font-black uppercase tracking-widest mb-1 opacity-60">Classification</p>
                        <p className="text-xl font-black uppercase">{analysis.riskClassification}</p>
                      </div>
                    </div>
                    <div className="lg:w-2/3 grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
                      {analysis.diseaseRisks?.map((r: any, idx: number) => (
                        <div key={idx} className="bg-white/5 border border-white/10 rounded-3xl p-6 hover:bg-white/10 transition-all group">
                          <div className="flex justify-between items-center mb-4">
                            <span className="text-[10px] font-black uppercase tracking-widest text-indigo-300 group-hover:text-white transition-colors">{r.disease}</span>
                            <span className="text-2xl font-black text-white">{r.probability}%</span>
                          </div>
                          <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                            <div className={`h-full transition-all duration-1000 ${r.probability > 60 ? 'bg-rose-500' : r.probability > 30 ? 'bg-amber-500' : 'bg-green-500'}`} style={{ width: `${r.probability}%` }}></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
            <HabitTracker profile={profile} onUpdate={u => setProfile(p => ({...p, ...u}))} feedback={habitFeedback} />
          </div>
        )}
        
        {activeTab === 'mental-health' && <MentalHealth />}
        {activeTab === 'vitality' && (
          <div className="animate-fadeIn grid grid-cols-1 lg:grid-cols-3 gap-8 h-[650px]">
            {/* Left Side: AuraChat Interface */}
            <div className="lg:col-span-2 bg-white rounded-[2.5rem] border border-slate-100 shadow-sm p-8 flex flex-col overflow-hidden relative">
              <div className="flex items-center justify-between mb-6 px-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white text-lg">🤖</div>
                  <div>
                    <h3 className="font-black text-slate-800 text-sm">AuraChat</h3>
                    <p className="text-[10px] text-green-500 font-bold uppercase tracking-tighter">Analyzing your clinical signatures</p>
                  </div>
                </div>
                {docSummary && (
                  <button onClick={handleAutoSummarize} className="text-[10px] font-black text-indigo-500 uppercase tracking-widest hover:underline">Re-Summarize Report</button>
                )}
              </div>
              
              <div className="flex-1 overflow-y-auto space-y-4 px-2 mb-6 scrollbar-hide">
                {chatHistory.length === 0 && !isTyping && (
                  <div className="h-full flex flex-col items-center justify-center text-center px-10">
                    <span className="text-4xl mb-4">✨</span>
                    <h4 className="font-black text-slate-800 mb-2">Ready to assist, {profile.firstName}.</h4>
                    <p className="text-xs text-slate-400 leading-relaxed max-w-xs">Ask me anything about your vitals, clinical report, or wellness routines.</p>
                  </div>
                )}
                {chatHistory.map((m, i) => (
                  <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-4 rounded-2xl text-sm font-medium leading-relaxed ${m.role === 'user' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-50 text-slate-700 border border-slate-100'}`}>
                      {m.content}
                    </div>
                  </div>
                ))}
                {isTyping && (
                  <div className="flex items-center gap-2 text-[10px] font-black text-indigo-400 animate-pulse tracking-widest uppercase">
                    <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full"></span>
                    AuraChat is processing clinical data...
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              <div className="flex gap-2 p-2 bg-slate-50 rounded-[2rem] border border-slate-200 shadow-inner">
                <input 
                  type="text" 
                  placeholder="Ask about your metabolic risks, clinical findings..." 
                  className="flex-1 bg-transparent border-none outline-none px-4 text-sm font-bold placeholder:text-slate-300" 
                  value={currentChatInput} 
                  onChange={e => setCurrentChatInput(e.target.value)} 
                  onKeyPress={e => e.key === 'Enter' && handleSendMessage()} 
                />
                <button 
                  onClick={handleSendMessage} 
                  disabled={!currentChatInput.trim() || isTyping} 
                  className={`px-8 py-3 rounded-[1.5rem] font-black text-[10px] uppercase tracking-widest shadow-lg transition-all ${currentChatInput.trim() && !isTyping ? 'bg-indigo-600 text-white hover:bg-indigo-700 active:scale-95' : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`}
                >
                  Send
                </button>
              </div>
            </div>

            {/* Right Side: About Me Sidebar */}
            <div className="flex flex-col gap-6">
              <div className="bg-[#0f172a] text-white p-8 rounded-[2.5rem] shadow-xl relative overflow-hidden border border-white/5 flex-1 flex flex-col">
                <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/10 rounded-full blur-[80px] -mr-24 -mt-24 pointer-events-none"></div>
                
                <div className="relative z-10 flex flex-col h-full">
                  <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.25em] mb-4">About AuraChat</h4>
                  <div className="w-12 h-1 bg-indigo-600 rounded-full mb-8"></div>
                  
                  <div className="space-y-6">
                    <p className="text-sm font-medium leading-relaxed text-slate-300">
                      I am <span className="text-white font-bold">AuraChat</span>, your dedicated medical-companion AI built to harmonize your clinical data into actionable wisdom.
                    </p>
                    <p className="text-sm font-medium leading-relaxed text-slate-300">
                      I specialize in translating complex metabolic signatures and clinical reports into simple, empathetic insights to help you navigate your health journey with confidence.
                    </p>
                  </div>

                  <div className="mt-auto pt-8 border-t border-white/10">
                    <div className="flex items-center gap-3 mb-4">
                      <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                      <span className="text-[10px] font-black uppercase tracking-widest">Active Diagnosis Mode</span>
                    </div>
                    <p className="text-[9px] text-slate-500 font-bold uppercase leading-relaxed">
                      Powered by AuraHealth Advanced Core v4.2. Synchronized with your local biometric signals.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
                <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Chat Quick Links</h5>
                <div className="space-y-2">
                  <button onClick={() => setCurrentChatInput("Explain my metabolic risks.")} className="w-full text-left p-3 rounded-xl hover:bg-slate-50 text-[10px] font-black text-indigo-600 uppercase border border-slate-50 transition-all">Metabolic Risks</button>
                  <button onClick={() => setCurrentChatInput("How can I improve my sleep score?")} className="w-full text-left p-3 rounded-xl hover:bg-slate-50 text-[10px] font-black text-indigo-600 uppercase border border-slate-50 transition-all">Sleep Coaching</button>
                </div>
              </div>
            </div>
          </div>
        )}
        {activeTab === 'medical' && <DoctorPortal profile={profile} summary={docSummary} onUpdateProfile={(p) => setProfile(prev => ({...prev, ...p}))} />}
        {activeTab === 'trends' && <Trends checkups={profile.checkups} onAddLog={(log) => setProfile(p => ({...p, checkups: [...p.checkups, log]}))} />}
        {activeTab === 'calendar' && <Calendar events={profile.events} onAddEvent={(event) => setProfile(p => ({...p, events: [...p.events, event]}))} />}
      </main>
    </div>
  );
};

export default App;
