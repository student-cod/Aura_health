
import React, { useState } from 'react';
import { UserProfile, Doctor } from '../types';

interface DoctorPortalProps {
  profile: UserProfile;
  summary: string;
  onUpdateProfile?: (updates: Partial<UserProfile>) => void;
}

const DOCTORS: Doctor[] = [
  { id: '1', name: 'Dr. Alicia Keys', specialization: 'Cardiology', email: 'akeys@aura.me', image: 'https://i.pravatar.cc/150?u=alicia' },
  { id: '2', name: 'Dr. Marcus Aurelius', specialization: 'General Physician', email: 'marcus@aura.me', image: 'https://i.pravatar.cc/150?u=marcus' },
  { id: '3', name: 'Dr. Sarah Connor', specialization: 'Orthopedics', email: 'sconnor@aura.me', image: 'https://i.pravatar.cc/150?u=sarah' },
  { id: '4', name: 'Dr. John Watson', specialization: 'Dentistry', email: 'jwatson@aura.me', image: 'https://i.pravatar.cc/150?u=watson' },
  { id: '5', name: 'Dr. Gregory House', specialization: 'Neurology', email: 'ghouse@aura.me', image: 'https://i.pravatar.cc/150?u=house' },
  { id: '6', name: 'Dr. Lisa Cuddy', specialization: 'Cardiology', email: 'lcuddy@aura.me', image: 'https://i.pravatar.cc/150?u=lisa' },
];

export const DoctorPortal: React.FC<DoctorPortalProps> = ({ profile, summary, onUpdateProfile }) => {
  const [selectedSpec, setSelectedSpec] = useState<string>('General Physician');
  const [bookingDate, setBookingDate] = useState<string>('');
  const [bookingDocId, setBookingDocId] = useState<string | null>(null);
  const [showSOS, setShowSOS] = useState(false);

  const getCleanSummary = (raw: string) => {
    if (!raw) return "";
    return raw.replace(/```html|```/g, '').trim();
  };

  const handleDownload = () => {
    const cleaned = getCleanSummary(summary);
    const fullHtml = cleaned.startsWith('<!DOCTYPE') 
      ? cleaned 
      : `<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:sans-serif;padding:40px;color:#334155;} .report-container{max-width:800px;margin:auto;border:1px solid #e2e8f0;padding:40px;border-radius:24px;background:#fff;}</style></head><body><div class="report-container">${cleaned}</div></body></html>`;
      
    const blob = new Blob([fullHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AuraHealth_Clinical_Report_${profile.firstName}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredDoctors = DOCTORS.filter(d => d.specialization === selectedSpec);

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-9 space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-slate-800">Clinical Summary</h2>
              <button 
                onClick={handleDownload}
                disabled={!summary}
                className="px-4 py-2 bg-indigo-600 text-white rounded-xl font-bold text-xs hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100 disabled:opacity-50"
              >
                Download HTML Report
              </button>
            </div>
            <div 
              className="p-6 bg-slate-50 rounded-2xl text-slate-600 text-sm leading-relaxed border border-slate-100 overflow-x-auto min-h-[200px]"
              dangerouslySetInnerHTML={{ __html: getCleanSummary(summary) || "<p class='italic opacity-60 uppercase font-black text-[10px] tracking-widest'>Your clinical summary is being finalized by AI...</p>" }}
            />
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-800">Diagnostic Reports Archive</h3>
              <input 
                type="file" 
                id="portal-upload" 
                className="hidden" 
                onChange={e => onUpdateProfile?.({ uploadedFile: e.target.files?.[0]?.name || null })} 
              />
              <label 
                htmlFor="portal-upload" 
                className="px-4 py-2 bg-slate-900 text-white rounded-xl font-black text-[10px] uppercase tracking-widest cursor-pointer hover:bg-black transition-all"
              >
                + Attach New Report
              </label>
            </div>
            
            {profile.uploadedFile ? (
              <div className="p-6 bg-indigo-50 border border-indigo-100 rounded-2xl flex items-center justify-between group">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-xl shadow-sm">📄</div>
                  <div>
                    <h5 className="text-sm font-bold text-slate-800 truncate max-w-[250px]">{profile.uploadedFile}</h5>
                    <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Added Successfully</p>
                  </div>
                </div>
                <button 
                  onClick={() => onUpdateProfile?.({ uploadedFile: null })}
                  className="text-[9px] font-black text-rose-500 uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  Delete
                </button>
              </div>
            ) : (
              <div className="p-12 border-2 border-dashed border-slate-100 rounded-2xl text-center">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">No diagnostic documents archived yet</p>
              </div>
            )}
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
            <h3 className="text-xl font-bold text-slate-800 mb-6">Specialized Medical Network</h3>
            <div className="flex flex-wrap gap-2 mb-8">
              {['General Physician', 'Cardiology', 'Orthopedics', 'Dentistry', 'Neurology'].map(spec => (
                <button 
                  key={spec}
                  onClick={() => setSelectedSpec(spec)}
                  className={`px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${selectedSpec === spec ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-50 text-slate-400 hover:bg-slate-100'}`}
                >
                  {spec}
                </button>
              ))}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredDoctors.map(doc => (
                <div key={doc.id} className="p-5 border border-slate-50 rounded-2xl flex flex-col transition-all bg-slate-50/50 hover:bg-white hover:shadow-md hover:border-indigo-100 group">
                  <div className="flex items-center gap-4 mb-4">
                    <img src={doc.image} className="w-14 h-14 rounded-full ring-2 ring-white shadow-sm" alt={doc.name} />
                    <div className="flex-1">
                      <h4 className="font-bold text-slate-800 text-sm">{doc.name}</h4>
                      <p className="text-[10px] text-slate-400 font-bold mb-2">{doc.email}</p>
                      <button 
                        onClick={() => {
                          if (bookingDocId === doc.id) setBookingDocId(null);
                          else { setBookingDocId(doc.id); setBookingDate(''); }
                        }}
                        className={`text-[10px] font-black uppercase tracking-wider ${bookingDocId === doc.id ? 'text-rose-500' : 'text-indigo-600 group-hover:underline'}`}
                      >
                        {bookingDocId === doc.id ? 'Cancel Booking' : 'Book Visit Now'}
                      </button>
                    </div>
                  </div>
                  
                  {bookingDocId === doc.id && (
                    <div className="mt-4 pt-4 border-t border-slate-200 animate-slideDown">
                      <p className="text-[10px] font-black text-indigo-400 uppercase mb-2">Select Date & Time</p>
                      <div className="flex gap-2">
                        <input 
                          type="date" 
                          className="flex-1 p-2 bg-white border border-slate-100 rounded-lg text-xs font-bold outline-none ring-2 ring-transparent focus:ring-indigo-100"
                          value={bookingDate} onChange={(e) => setBookingDate(e.target.value)}
                        />
                        <button 
                          disabled={!bookingDate}
                          onClick={() => { alert(`Success! Appointment confirmed for ${bookingDate} with ${doc.name}`); setBookingDocId(null); }}
                          className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-[10px] font-black uppercase disabled:opacity-50 hover:bg-indigo-700 transition-all shadow-sm"
                        >
                          Confirm
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-3 space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
            <h3 className="text-xl font-bold text-slate-800 mb-4 tracking-tight">System Status</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400">Clinic Availability</span>
                <span className="text-xs font-black text-green-500">OPTIMAL</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400">AI Triage Latency</span>
                <span className="text-xs font-black text-slate-800">12ms</span>
              </div>
              <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-2xl">
                <p className="text-[10px] text-indigo-900 font-bold leading-relaxed">
                  Tip: Early morning appointments typically have 20% faster check-in times.
                </p>
              </div>
            </div>
          </div>

          <div className="relative group mt-10">
            <button 
              onClick={() => setShowSOS(!showSOS)}
              className="w-full p-8 bg-rose-600 hover:bg-rose-700 transition-all rounded-[2.5rem] text-white shadow-xl shadow-rose-100 flex flex-col items-center hover:scale-[1.02] active:scale-95"
            >
              <span className="text-3xl mb-2">🆘</span>
              <span className="text-sm font-black tracking-[0.2em] uppercase">Emergency Hub</span>
            </button>
            
            {showSOS && (
              <div className="absolute top-0 left-0 w-full h-full bg-[#0f172a] rounded-[2.5rem] p-4 text-white flex flex-col items-center justify-center animate-fadeIn z-10 text-center border border-white/10 shadow-2xl">
                <p className="text-[10px] font-black mb-3 uppercase tracking-[0.25em] text-slate-400">emergency call</p>
                <div className="space-y-4 w-full px-2">
                  <a href="tel:911" className="group block w-full py-3.5 bg-rose-600 rounded-2xl text-center font-black hover:bg-rose-700 transition-all uppercase tracking-widest text-[11px] flex items-center justify-center gap-3 shadow-lg shadow-rose-900/20">
                    <svg className="w-4 h-4 text-white fill-current" viewBox="0 0 24 24"><path d="M6.62,10.79C8.06,13.62 10.38,15.94 13.21,17.38L15.41,15.18C15.69,14.9 16.08,14.82 16.43,14.93C17.55,15.3 18.75,15.5 20,15.5A1,1 0 0,1 21,16.5V20A1,1 0 0,1 20,21A17,17 0 0,1 3,4A1,1 0 0,1 4,3H7.5A1,1 0 0,1 8.5,4C8.5,5.25 8.7,6.45 9.07,7.57C9.18,7.92 9.1,8.31 8.82,8.59L6.62,10.79Z"/></svg>
                    911
                  </a>
                  <div className="space-y-1.5 pt-2">
                    <p className="text-[8px] font-bold text-slate-600 uppercase tracking-widest">Hub ID: AURA-992-SOS</p>
                    <button onClick={() => setShowSOS(false)} className="block w-full text-[9px] font-black text-slate-400 hover:text-white uppercase tracking-widest py-1 transition-colors">Return to Dashboard</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
