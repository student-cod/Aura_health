
import React, { useState, useEffect } from 'react';
import { CalendarEvent } from '../types';

interface CalendarProps {
  events: CalendarEvent[];
  onAddEvent: (event: CalendarEvent) => void;
}

export const Calendar: React.FC<CalendarProps> = ({ events, onAddEvent }) => {
  const [showAdd, setShowAdd] = useState(false);
  const [newEvent, setNewEvent] = useState<Omit<CalendarEvent, 'id'>>({
    title: '',
    date: new Date().toISOString().split('T')[0],
    time: '10:00',
    type: 'Appointment'
  });

  const [alerts, setAlerts] = useState<string[]>([]);
  const isEventValid = newEvent.title.trim() !== '';

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    const tomorrowDate = new Date();
    tomorrowDate.setDate(tomorrowDate.getDate() + 1);
    const tomorrow = tomorrowDate.toISOString().split('T')[0];

    const newAlerts: string[] = [];
    events.forEach(e => {
      if (e.date === today) {
        newAlerts.push(`Reminder: You have a ${e.type} "${e.title}" scheduled for TODAY at ${e.time}.`);
      } else if (e.date === tomorrow) {
        newAlerts.push(`Heads up! Tomorrow: ${e.type} "${e.title}" at ${e.time}.`);
      }
    });
    setAlerts(newAlerts);
  }, [events]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isEventValid) return;
    onAddEvent({ ...newEvent, id: Date.now().toString() });
    setShowAdd(false);
    setNewEvent({ title: '', date: new Date().toISOString().split('T')[0], time: '10:00', type: 'Appointment' });
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-black text-slate-900">Health Scheduler</h2>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Protocol & Timeline</p>
        </div>
        <button 
          onClick={() => setShowAdd(!showAdd)}
          className="px-6 py-3 bg-indigo-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:bg-indigo-700 transition-all"
        >
          {showAdd ? 'Cancel' : '+ Schedule Event'}
        </button>
      </div>

      {alerts.length > 0 && (
        <div className="space-y-3">
          {alerts.map((alert, i) => (
            <div key={i} className="bg-amber-50 border border-amber-100 p-4 rounded-2xl flex items-center gap-4 animate-slideDown">
              <span className="text-xl">🔔</span>
              <p className="text-[11px] font-black text-amber-800 uppercase tracking-tight">{alert}</p>
            </div>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {showAdd ? (
            <form onSubmit={handleSubmit} className="bg-white p-10 rounded-[3rem] border border-indigo-100 shadow-xl animate-fadeIn">
              <div className="space-y-6">
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-slate-400 uppercase ml-2">Event Title</label>
                  <input type="text" placeholder="What is the occasion?" className="w-full p-4 bg-slate-50 rounded-2xl border-none font-bold" value={newEvent.title} onChange={e => setNewEvent({...newEvent, title: e.target.value})} />
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-400 uppercase ml-2">Date</label>
                    <input type="date" className="w-full p-4 bg-slate-50 rounded-2xl border-none font-bold" value={newEvent.date} onChange={e => setNewEvent({...newEvent, date: e.target.value})} />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-400 uppercase ml-2">Time</label>
                    <input type="time" className="w-full p-4 bg-slate-50 rounded-2xl border-none font-bold" value={newEvent.time} onChange={e => setNewEvent({...newEvent, time: e.target.value})} />
                  </div>
                </div>
                <button 
                  type="submit" 
                  disabled={!isEventValid}
                  className={`w-full py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all shadow-lg ${isEventValid ? 'bg-indigo-600 text-white hover:bg-indigo-700' : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`}
                >
                  Confirm Appointment
                </button>
              </div>
            </form>
          ) : (
            <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm p-8">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-8">Upcoming Agenda</h4>
              {events.length === 0 ? (
                <div className="text-center py-20 opacity-20">
                  <span className="text-5xl block mb-4">📅</span>
                  <p className="text-xs font-black uppercase">No scheduled protocols</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {events.sort((a,b) => a.date.localeCompare(b.date)).map(event => (
                    <div key={event.id} className="p-6 bg-slate-50 rounded-[2rem] border border-slate-100 flex items-center justify-between">
                      <div className="flex items-center gap-6">
                        <div className="w-14 h-14 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl">🩺</div>
                        <div>
                          <h5 className="text-sm font-black text-slate-800">{event.title}</h5>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{event.date}</p>
                        </div>
                      </div>
                      <span className="px-4 py-2 bg-white rounded-xl text-[10px] font-black text-slate-600 shadow-sm">{event.time}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
