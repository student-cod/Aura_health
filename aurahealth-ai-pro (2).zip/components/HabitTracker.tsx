
import React, { useState } from 'react';
import { UserProfile } from '../types';

interface HabitTrackerProps {
  profile: UserProfile;
  onUpdate: (updates: Partial<UserProfile>) => void;
  feedback?: any[];
}

export const HabitTracker: React.FC<HabitTrackerProps> = ({ profile, onUpdate, feedback = [] }) => {
  const [editing, setEditing] = useState<string | null>(null);

  // Logic-based real-time tips
  const getDynamicTips = () => {
    const tips = [];
    if (profile.hydration < 2.5) {
      tips.push({
        type: 'warning',
        title: 'Hydration Deficit',
        message: 'Your water intake is below the 2.5L optimal threshold. Low hydration can lead to cognitive fatigue.',
        icon: '💧'
      });
    }
    if (profile.sleep < 7) {
      tips.push({
        type: 'alert',
        title: 'Sleep Imbalance',
        message: 'Resting for less than 7 hours affects metabolic recovery. Try to aim for 8 hours tonight.',
        icon: '🌙'
      });
    }
    if (profile.steps < 10000) {
      tips.push({
        type: 'info',
        title: 'Activity Goal',
        message: `You're at ${profile.steps} steps. A quick 15-minute walk will boost your heart health score.`,
        icon: '👣'
      });
    }
    if (profile.heartRate > 85) {
      tips.push({
        type: 'warning',
        title: 'Elevated BPM',
        message: 'Your resting heart rate is slightly high. Consider a 2-minute breathing exercise in the Mind section.',
        icon: '❤️'
      });
    }
    return tips;
  };

  const dynamicTips = getDynamicTips();

  const StatCard = ({ title, value, unit, keyName, icon, badge, bgIconColor }: any) => (
    <div className="p-5 bg-white rounded-2xl shadow-[0_4px_20px_rgba(0,0,0,0.03)] border border-slate-50 flex flex-col justify-between relative group hover:shadow-lg transition-all">
      <div className="flex justify-between items-start mb-6">
        <div className={`w-10 h-10 ${bgIconColor} rounded-xl flex items-center justify-center text-lg`}>
          {icon}
        </div>
        {badge && (
          <span className="px-2 py-1 bg-green-50 text-green-600 text-[10px] font-black rounded-lg uppercase tracking-widest">
            {badge}
          </span>
        )}
        <button 
          onClick={() => setEditing(editing === keyName ? null : keyName)}
          className="absolute bottom-2 right-4 text-indigo-400 text-[8px] font-black uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity"
        >
          {editing === keyName ? 'Done' : 'Manual Entry'}
        </button>
      </div>

      <div>
        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{title}</h4>
        {editing === keyName ? (
          <div className="flex items-center gap-2">
            <input 
              autoFocus
              type="text" 
              className="text-2xl font-black text-slate-800 w-full bg-slate-50 border-none outline-none rounded-lg px-2"
              value={keyName === 'bloodPressure' ? `${profile.bloodPressure.systolic}/${profile.bloodPressure.diastolic}` : value}
              onChange={(e) => {
                const val = e.target.value;
                if (keyName === 'bloodPressure') {
                  const [sys, dia] = val.split('/').map(n => parseInt(n) || 0);
                  onUpdate({ bloodPressure: { systolic: sys || 0, diastolic: dia || 0 } });
                } else {
                  onUpdate({ [keyName]: parseFloat(val) || 0 });
                }
              }}
              onBlur={() => setEditing(null)}
              onKeyDown={(e) => e.key === 'Enter' && setEditing(null)}
            />
          </div>
        ) : (
          <p className="text-2xl font-black text-slate-800 flex items-baseline gap-1">
            {keyName === 'bloodPressure' ? `${profile.bloodPressure.systolic}/${profile.bloodPressure.diastolic}` : value}
            <span className="text-[10px] font-bold text-slate-400 uppercase">{unit}</span>
          </p>
        )}
      </div>
    </div>
  );

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Vitals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-5">
        <StatCard 
          title="Heart Rate" 
          value={profile.heartRate} 
          unit="BPM" 
          keyName="heartRate" 
          icon="❤️" 
          badge="STEADY" 
          bgIconColor="bg-rose-50" 
        />
        <StatCard 
          title="SPO2 Level" 
          value={profile.spo2} 
          unit="%" 
          keyName="spo2" 
          icon="💧" 
          bgIconColor="bg-blue-50" 
        />
        <StatCard 
          title="Blood Pressure" 
          value={`${profile.bloodPressure.systolic}/${profile.bloodPressure.diastolic}`} 
          unit="MMHG" 
          keyName="bloodPressure" 
          icon="📈" 
          bgIconColor="bg-indigo-50" 
        />
        <StatCard 
          title="Sleep Track" 
          value={profile.sleep} 
          unit="HRS" 
          keyName="sleep" 
          icon="🌙" 
          bgIconColor="bg-purple-50" 
        />
        <StatCard 
          title="Step Count" 
          value={profile.steps} 
          unit="STEPS" 
          keyName="steps" 
          icon="👣" 
          badge="ACTIVE" 
          bgIconColor="bg-orange-50" 
        />
        <StatCard 
          title="Breathing" 
          value={profile.breathing} 
          unit="RPM" 
          keyName="breathing" 
          icon="🌡️" 
          bgIconColor="bg-teal-50" 
        />
      </div>

      {/* AI Wellness Dashboard Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
            <h3 className="text-xl font-black text-slate-900 mb-6 flex items-center gap-2">
              <span className="text-indigo-600">✨</span> AI Health Recommendations
            </h3>
            <div className="space-y-4">
              {dynamicTips.map((tip, idx) => (
                <div key={idx} className={`p-5 rounded-3xl border flex items-start gap-4 transition-all hover:translate-x-1 ${
                  tip.type === 'warning' ? 'bg-amber-50 border-amber-100' : 
                  tip.type === 'alert' ? 'bg-rose-50 border-rose-100' : 'bg-indigo-50 border-indigo-100'
                }`}>
                  <div className="text-2xl mt-1">{tip.icon}</div>
                  <div>
                    <h5 className={`font-black text-sm uppercase tracking-wider mb-1 ${
                      tip.type === 'warning' ? 'text-amber-700' : 
                      tip.type === 'alert' ? 'text-rose-700' : 'text-indigo-700'
                    }`}>
                      {tip.title}
                    </h5>
                    <p className="text-sm text-slate-600 font-medium leading-relaxed">{tip.message}</p>
                  </div>
                </div>
              ))}
              {feedback.length > 0 && feedback.map((f, idx) => (
                <div key={`gemini-${idx}`} className="p-5 rounded-3xl border border-indigo-100 bg-indigo-50/30 flex items-start gap-4">
                  <div className="text-2xl mt-1">🤖</div>
                  <div>
                    <h5 className="font-black text-sm uppercase tracking-wider mb-1 text-indigo-700">{f.title}</h5>
                    <p className="text-sm text-slate-600 font-medium leading-relaxed">{f.tip || f.advice}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden h-full flex flex-col justify-between">
            <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl -mr-16 -mt-16"></div>
            <div>
              <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">Cycle Analysis</h4>
              <p className="text-lg font-black leading-tight mb-4">You are in Peak Performance Stage.</p>
              <div className="space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-bold">Metabolic Sync</span>
                  <span className="font-black text-green-400">98%</span>
                </div>
                <div className="w-full bg-white/10 h-1 rounded-full overflow-hidden">
                  <div className="bg-green-400 h-full w-[98%]"></div>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-bold">Sleep Quality</span>
                  <span className="font-black text-amber-400">72%</span>
                </div>
                <div className="w-full bg-white/10 h-1 rounded-full overflow-hidden">
                  <div className="bg-amber-400 h-full w-[72%]"></div>
                </div>
              </div>
            </div>
            <div className="mt-8">
              <p className="text-[10px] text-slate-500 font-bold uppercase leading-relaxed">
                Bio-signature synchronization detected. Your resting heart rate of {profile.heartRate} BPM indicates a stable metabolic state.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
