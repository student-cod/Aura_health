
import React, { useState } from 'react';
import { CheckupLog } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

interface TrendsProps {
  checkups: CheckupLog[];
  onAddLog: (log: CheckupLog) => void;
}

export const Trends: React.FC<TrendsProps> = ({ checkups, onAddLog }) => {
  const [showForm, setShowForm] = useState(false);
  const [newLog, setNewLog] = useState<Omit<CheckupLog, 'id'>>({
    date: new Date().toISOString().split('T')[0],
    weight: 0,
    heartRate: 0,
    systolic: 0,
    diastolic: 0,
    bloodSugar: 0
  });

  // Reorder values: Ensure they are always sorted by date ascending for the charts
  const sortedCheckups = [...checkups].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const isFormValid = newLog.weight > 0 && newLog.heartRate > 0 && newLog.systolic > 0 && newLog.diastolic > 0 && newLog.bloodSugar > 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormValid) return;
    onAddLog({ ...newLog, id: Date.now().toString() });
    setShowForm(false);
    setNewLog({
      date: new Date().toISOString().split('T')[0],
      weight: 0,
      heartRate: 0,
      systolic: 0,
      diastolic: 0,
      bloodSugar: 0
    });
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-black text-slate-900">Biometric Trends</h2>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Historical Data Visualization • Auto-Synced</p>
        </div>
        <button 
          onClick={() => setShowForm(!showForm)}
          className="px-6 py-3 bg-indigo-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:bg-indigo-700 transition-all"
        >
          {showForm ? 'Cancel Entry' : '+ Log Checkup Result'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white p-8 rounded-[2.5rem] border border-indigo-100 shadow-xl animate-slideDown mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-1">
              <label className="text-[9px] font-bold text-slate-400 uppercase ml-2">Date</label>
              <input type="date" className="w-full p-4 bg-slate-50 rounded-2xl border-none font-bold" value={newLog.date} onChange={e => setNewLog({...newLog, date: e.target.value})} />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-bold text-slate-400 uppercase ml-2">Weight (kg)</label>
              <input type="number" placeholder="Enter Weight" className="w-full p-4 bg-slate-50 rounded-2xl border-none font-bold" value={newLog.weight || ''} onChange={e => setNewLog({...newLog, weight: Number(e.target.value)})} />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-bold text-slate-400 uppercase ml-2">Heart Rate</label>
              <input type="number" placeholder="Enter BPM" className="w-full p-4 bg-slate-50 rounded-2xl border-none font-bold" value={newLog.heartRate || ''} onChange={e => setNewLog({...newLog, heartRate: Number(e.target.value)})} />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-bold text-slate-400 uppercase ml-2">Systolic</label>
              <input type="number" placeholder="BP Sys" className="w-full p-4 bg-slate-50 rounded-2xl border-none font-bold" value={newLog.systolic || ''} onChange={e => setNewLog({...newLog, systolic: Number(e.target.value)})} />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-bold text-slate-400 uppercase ml-2">Diastolic</label>
              <input type="number" placeholder="BP Dia" className="w-full p-4 bg-slate-50 rounded-2xl border-none font-bold" value={newLog.diastolic || ''} onChange={e => setNewLog({...newLog, diastolic: Number(e.target.value)})} />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-bold text-slate-400 uppercase ml-2">Blood Sugar</label>
              <input type="number" placeholder="Enter mg/dL" className="w-full p-4 bg-slate-50 rounded-2xl border-none font-bold" value={newLog.bloodSugar || ''} onChange={e => setNewLog({...newLog, bloodSugar: Number(e.target.value)})} />
            </div>
          </div>
          <button 
            type="submit" 
            disabled={!isFormValid}
            className={`mt-8 w-full py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all shadow-lg ${isFormValid ? 'bg-slate-900 text-white hover:bg-black' : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`}
          >
            Submit Entry
          </button>
        </form>
      )}

      {sortedCheckups.length === 0 ? (
        <div className="bg-white p-20 rounded-[2.5rem] border border-slate-100 text-center text-slate-300 font-black uppercase text-xs tracking-[0.2em]">
          No data logged. Visualizations will appear once checkups are recorded.
        </div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
          <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-8">Blood Pressure Progression</h4>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sortedCheckups}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="date" stroke="#94a3b8" fontSize={9} tickFormatter={(val) => val.split('-').slice(1).join('/')} />
                  <YAxis stroke="#94a3b8" fontSize={10} fontWeight="bold" />
                  <Tooltip contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                  <Legend iconType="circle" />
                  <Line type="monotone" dataKey="systolic" stroke="#6366f1" strokeWidth={4} />
                  <Line type="monotone" dataKey="diastolic" stroke="#94a3b8" strokeWidth={4} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-8">Sugar & Heart Rate</h4>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sortedCheckups}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="date" stroke="#94a3b8" fontSize={9} />
                  <YAxis stroke="#94a3b8" fontSize={10} fontWeight="bold" />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="bloodSugar" stroke="#f43f5e" strokeWidth={4} />
                  <Line type="monotone" dataKey="heartRate" stroke="#10b981" strokeWidth={4} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
